export interface Player {
  id: string;
  name: string;
  position: string;
  stats: {
    battingAverage: number;
    homeRuns: number;
    rbi: number;
  };
}

export interface GameState {
  inning: number;
  isTopInning: boolean;
  outs: number;
  balls: number;
  strikes: number;
  baseRunners: (Player | null)[];
  currentBatter: Player | null;
  currentPitcher: Player | null;
  homeScore: number;
  awayScore: number;
}

export interface PredictedOutcome {
  success: number;
  description: string;
  potentialResults: string[];
}