import React from 'react';
import { Search } from 'lucide-react';

interface MetricProps {
  label: string;
  value: string | number;
  change?: string;
}

const Metric = ({ label, value, change }: MetricProps) => (
  <div className="mb-8">
    <h3 className="text-lg mb-2">{label}</h3>
    <div className="flex items-baseline gap-2">
      <span className="text-4xl font-bold">{value}</span>
      {change && (
        <span className={`text-sm ${change.startsWith('+') ? 'text-green-500' : 'text-red-500'}`}>
          {change}
        </span>
      )}
    </div>
    <div className="mt-4 h-24 bg-[#29374C] rounded-lg" /> {/* Placeholder for chart */}
  </div>
);

export const GameDetailsPage = () => {
  return (
    <div className="min-h-screen bg-[#131C24] text-white">
      <header className="flex items-center justify-between p-4">
        <h1 className="text-2xl font-bold">Game 1</h1>
        <Search size={24} />
      </header>

      <div className="p-4">
        <h2 className="text-xl font-bold mb-6">Predictive Metrics</h2>

        <Metric label="Win Probability" value="80%" change="+5%" />
        <Metric label="Runs Scored" value="4.8" change="-0.2" />
        <Metric label="Batter Success Rate" value="40%" change="+2%" />
        <Metric label="Pitcher Success Rate" value="50%" change="+1%" />

        <button className="w-full bg-[#F4C753] text-[#131C24] font-bold py-4 rounded-lg mt-8">
          Make Decision
        </button>
      </div>
    </div>
  );
}