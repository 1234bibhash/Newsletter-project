import React from 'react';
import { Search } from 'lucide-react';

export const GamePage = () => {
  return (
    <div className="min-h-screen bg-[#131C24] text-white">
      <header className="flex items-center justify-between p-4">
        <button className="text-white">
          <span className="sr-only">Back</span>
          ←
        </button>
        <h1 className="text-2xl font-bold">Choose a game</h1>
        <div className="w-8" />
      </header>

      <div className="p-4">
        <div className="relative">
          <input
            type="search"
            placeholder="Search for games"
            className="w-full bg-[#29374C] text-white placeholder-gray-400 rounded-lg py-3 px-4 pl-10"
          />
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
        </div>

        <section className="mt-8">
          <h2 className="text-2xl font-bold mb-4">Classic Games</h2>
          <div className="grid grid-cols-2 gap-4">
            {['1988 World Series Game 1', '2013 All-Star Game', '1999 ALCS Game 5'].map((game) => (
              <div key={game} className="aspect-video bg-[#29374C] rounded-lg p-4">
                <h3 className="font-bold">{game}</h3>
              </div>
            ))}
          </div>
        </section>

        <section className="mt-8">
          <h2 className="text-2xl font-bold mb-4">Featured Collections</h2>
          <div className="grid grid-cols-2 gap-4">
            {['Grand Slams', 'Pitching Duels', 'No Hitters'].map((collection) => (
              <div key={collection} className="aspect-video bg-[#29374C] rounded-lg p-4">
                <h3 className="font-bold">{collection}</h3>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}