import React from 'react';
import { Trophy } from 'lucide-react';

export const ProfilePage = () => {
  const scores = [
    { week: 'Week 2', score: 1823 },
    { week: 'Week 1', score: 1732 }
  ];

  const leaderboards = [
    { type: 'Weekly', place: '5th place' },
    { type: 'Monthly', place: '12th place' },
    { type: 'Yearly', place: '34th place' }
  ];

  const achievements = [
    { title: 'All-Star', description: "You've won over $100 this year" },
    { title: 'Big Spender', description: "You've spent over $100 on entries this year" },
    { title: 'Perfect Lineup', description: 'You picked the perfect lineup' }
  ];

  return (
    <div className="min-h-screen bg-[#131C24] text-white p-4">
      <h1 className="text-2xl font-bold text-center mb-8">FanDuel</h1>

      <div className="text-center mb-8">
        <div className="w-24 h-24 bg-[#29374C] rounded-full mx-auto mb-4" />
        <h2 className="text-2xl font-bold mb-2">Wesley, you're in 5th place!</h2>
        <p className="text-[#8A9DC0]">
          Keep climbing the leaderboard to win a share of $5000 every week!
        </p>
      </div>

      <button className="w-full bg-[#29374C] text-white font-bold py-4 rounded-lg mb-8">
        Play Now
      </button>

      <section className="mb-8">
        <h3 className="text-xl font-bold mb-4">Your Scores</h3>
        {scores.map(({ week, score }) => (
          <div key={week} className="flex justify-between items-center mb-4">
            <span>{week}</span>
            <span className="font-bold">{score}</span>
          </div>
        ))}
      </section>

      <section className="mb-8">
        <h3 className="text-xl font-bold mb-4">Leaderboards</h3>
        {leaderboards.map(({ type, place }) => (
          <div key={type} className="flex justify-between items-center mb-4">
            <span>{type}</span>
            <span>{place}</span>
          </div>
        ))}
      </section>

      <section>
        <h3 className="text-xl font-bold mb-4">Achievements</h3>
        {achievements.map(({ title, description }) => (
          <div key={title} className="flex items-center justify-between mb-4">
            <div>
              <h4 className="font-bold">{title}</h4>
              <p className="text-[#8A9DC0] text-sm">{description}</p>
            </div>
            <Trophy className="text-[#F4C753]" />
          </div>
        ))}
      </section>
    </div>
  );
}