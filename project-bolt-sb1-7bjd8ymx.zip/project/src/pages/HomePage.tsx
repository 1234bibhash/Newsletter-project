import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Header } from '../components/layout/Header';
import { HeroSection } from '../components/hero/HeroSection';
import { FeatureCard } from '../components/features/FeatureCard';

const features = [
  {
    title: 'FanGraphs Points League',
    description: 'Draft a team and manage the strategy',
    imageUrl: '/images/points-league.jpg'
  },
  {
    title: 'FanGraphs Auctions',
    description: 'Use your points to buy players and compete for prizes',
    imageUrl: '/images/auctions.jpg'
  },
  {
    title: 'Private Leagues',
    description: 'Set up a private league with your friends',
    imageUrl: '/images/private-leagues.jpg'
  }
];

export const HomePage = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-[#131C24] flex flex-col">
      <Header />
      <HeroSection />
      
      <main className="flex-1">
        {features.map((feature, index) => (
          <FeatureCard key={index} {...feature} />
        ))}
        
        <div className="p-4">
          <button 
            onClick={() => navigate('/games')}
            className="w-full h-12 bg-[#F4C753] text-[#141C24] font-bold rounded-xl"
          >
            Start Drafting
          </button>
        </div>
      </main>
    </div>
  );
};