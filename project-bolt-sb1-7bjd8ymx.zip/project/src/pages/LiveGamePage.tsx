import React from 'react';

const pitchTypes = ['Fastball', 'Curveball', 'Slider', 'Changeup', 'Sinker'];

export const LiveGamePage = () => {
  return (
    <div className="min-h-screen bg-[#131C24] text-white p-4">
      <h1 className="text-2xl font-bold text-center mb-8">Live Game</h1>

      <div className="mb-8">
        <div className="bg-[#F4C753] h-2 rounded-full w-1/4" />
        <p className="text-[#8A9DC0] mt-2">Pitch 1</p>
      </div>

      <div className="mb-12">
        <h2 className="text-3xl font-bold mb-8">
          Select the pitch type for the next play
        </h2>

        <div className="grid grid-cols-2 gap-4">
          {pitchTypes.map((pitch) => (
            <button
              key={pitch}
              className="bg-[#29374C] text-white py-3 px-6 rounded-lg text-lg"
            >
              {pitch}
            </button>
          ))}
        </div>
      </div>

      <button className="w-full bg-[#F4C753] text-[#131C24] font-bold py-4 rounded-lg mt-auto">
        Submit
      </button>
    </div>
  );
}