import React from 'react';

interface ActionButtonProps {
  children: React.ReactNode;
  onClick?: () => void;
}

export const ActionButton = ({ children, onClick }: ActionButtonProps) => (
  <button
    onClick={onClick}
    className="flex min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-xl h-12 px-5 flex-1 bg-[#F4C753] text-[#141C24] text-base font-bold leading-normal tracking-[0.015em]"
  >
    <span className="truncate">{children}</span>
  </button>
);