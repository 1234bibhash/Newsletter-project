import React from 'react';
import { Baseball } from 'lucide-react';
import { useGameStore } from '../store/gameStore';

export const GameField = () => {
  const { gameState } = useGameStore();
  
  return (
    <div className="relative w-full max-w-2xl aspect-square bg-green-800 rounded-full p-8">
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="w-2/3 h-2/3 border-white border-8 rotate-45 diamond-base">
          {/* Bases */}
          {gameState.baseRunners.map((runner, index) => (
            <div
              key={index}
              className={`absolute w-8 h-8 ${
                runner ? 'bg-white' : 'bg-gray-300'
              } transform rotate-45`}
              style={{
                ...(index === 0 && { bottom: '-1rem', right: '-1rem' }), // First base
                ...(index === 1 && { top: '-1rem', right: '-1rem' }), // Second base
                ...(index === 2 && { top: '-1rem', left: '-1rem' }), // Third base
              }}
            />
          ))}
          
          {/* Home plate */}
          <div className="absolute bottom-[-2rem] left-1/2 transform -translate-x-1/2">
            <Baseball className="w-8 h-8 text-white" />
          </div>
        </div>
      </div>
    </div>
  );
};