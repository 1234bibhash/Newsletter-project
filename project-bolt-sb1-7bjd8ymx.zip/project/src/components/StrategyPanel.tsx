import React from 'react';
import { Target, Shield, RotateCcw } from 'lucide-react';

export const StrategyPanel = () => {
  const handlePitchStrategy = () => {
    // TODO: Implement pitch strategy logic
  };

  const handleDefensiveAlignment = () => {
    // TODO: Implement defensive alignment logic
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-lg">
      <h2 className="text-2xl font-bold mb-4">Strategy Options</h2>
      
      <div className="space-y-4">
        <button
          onClick={handlePitchStrategy}
          className="w-full flex items-center justify-between p-4 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors"
        >
          <div className="flex items-center gap-3">
            <Target className="w-6 h-6 text-blue-600" />
            <span className="font-semibold">Pitch Strategy</span>
          </div>
          <span className="text-blue-600">→</span>
        </button>

        <button
          onClick={handleDefensiveAlignment}
          className="w-full flex items-center justify-between p-4 bg-green-50 hover:bg-green-100 rounded-lg transition-colors"
        >
          <div className="flex items-center gap-3">
            <Shield className="w-6 h-6 text-green-600" />
            <span className="font-semibold">Defensive Alignment</span>
          </div>
          <span className="text-green-600">→</span>
        </button>

        <button
          className="w-full flex items-center justify-between p-4 bg-purple-50 hover:bg-purple-100 rounded-lg transition-colors"
        >
          <div className="flex items-center gap-3">
            <RotateCcw className="w-6 h-6 text-purple-600" />
            <span className="font-semibold">Historical Replay</span>
          </div>
          <span className="text-purple-600">→</span>
        </button>
      </div>
    </div>
  );
};