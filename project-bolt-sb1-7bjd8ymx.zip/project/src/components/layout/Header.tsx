import React from 'react';
import { User } from 'lucide-react';

export const Header = () => (
  <header className="flex items-center bg-[#131C24] p-4 pb-2 justify-between">
    <h2 className="text-[#F8F9FB] text-lg font-bold leading-tight tracking-[-0.015em] flex-1 text-center pl-12">
      Home
    </h2>
    <div className="flex w-12 items-center justify-end">
      <button className="flex cursor-pointer items-center justify-center overflow-hidden rounded-xl h-12 bg-transparent text-[#F8F9FB]">
        <User size={24} />
      </button>
    </div>
  </header>
);