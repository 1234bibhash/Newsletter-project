import React from 'react';
import { Outlet } from 'react-router-dom';
import { AppNav } from '../navigation/AppNav';

export const Layout = () => {
  return (
    <div className="min-h-screen bg-[#131C24] flex flex-col">
      <main className="flex-1">
        <Outlet />
      </main>
      <AppNav />
    </div>
  );
};