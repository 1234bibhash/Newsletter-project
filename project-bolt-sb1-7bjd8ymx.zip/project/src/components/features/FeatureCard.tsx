import React from 'react';

interface FeatureCardProps {
  title: string;
  description: string;
  imageUrl: string;
}

export const FeatureCard = ({ title, description, imageUrl }: FeatureCardProps) => (
  <div className="p-4">
    <div className="rounded-xl overflow-hidden">
      <img 
        src={imageUrl} 
        alt={title}
        className="w-full aspect-video object-cover"
      />
      <div className="py-4">
        <h3 className="text-[#F8F9FB] text-lg font-bold leading-tight mb-1">
          {title}
        </h3>
        <p className="text-[#8A9DC0] text-base">
          {description}
        </p>
      </div>
    </div>
  </div>
);