import React from 'react';
import { Home, Pencil, Users, User, Newspaper } from 'lucide-react';

interface NavItemProps {
  Icon: React.ComponentType<any>;
  label: string;
  isActive?: boolean;
}

const NavItem = ({ Icon, label, isActive = false }: NavItemProps) => (
  <a 
    href="#" 
    className={`flex flex-1 flex-col items-center gap-1 ${
      isActive ? 'text-[#F8F9FB]' : 'text-[#8A9DC0]'
    }`}
  >
    <Icon size={24} />
    <span className="text-xs font-medium">{label}</span>
  </a>
);

export const BottomNav = () => (
  <nav className="mt-auto border-t border-[#29374C] bg-[#1D2A36] px-4 py-3">
    <div className="flex justify-between">
      <NavItem Icon={Home} label="Home" isActive />
      <NavItem Icon={Pencil} label="Draft" />
      <NavItem Icon={Users} label="My Teams" />
      <NavItem Icon={User} label="Players" />
      <NavItem Icon={Newspaper} label="News" />
    </div>
  </nav>
);