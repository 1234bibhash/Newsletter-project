import React from 'react';
import { NavLink } from 'react-router-dom';
import { Home, Trophy, Users, User, Newspaper } from 'lucide-react';

interface NavItemProps {
  Icon: React.ComponentType<any>;
  label: string;
  to: string;
}

const NavItem = ({ Icon, label, to }: NavItemProps) => (
  <NavLink 
    to={to}
    className={({ isActive }) => `flex flex-col items-center gap-1 ${
      isActive ? 'text-[#F4C753]' : 'text-[#8A9DC0]'
    }`}
  >
    <Icon size={24} />
    <span className="text-xs font-medium">{label}</span>
  </NavLink>
);

export const AppNav = () => (
  <nav className="border-t border-[#29374C] bg-[#1D2A36] px-4 py-3">
    <div className="flex justify-between">
      <NavItem Icon={Home} label="Home" to="/" />
      <NavItem Icon={Trophy} label="Games" to="/games" />
      <NavItem Icon={Users} label="My Teams" to="/teams" />
      <NavItem Icon={User} label="Players" to="/players" />
      <NavItem Icon={Newspaper} label="News" to="/news" />
    </div>
  </nav>
);