import React from 'react';

export const HeroSection = () => (
  <section className="relative h-[480px] bg-cover bg-center bg-no-repeat p-4"
    style={{
      backgroundImage: 'linear-gradient(rgba(0, 0, 0, 0.1) 0%, rgba(0, 0, 0, 0.4) 100%), url("/images/baseball-field.jpg")'
    }}>
    <div className="absolute bottom-10 left-4 right-4">
      <h1 className="text-white text-4xl font-black leading-tight tracking-[-0.033em] mb-2">
        Welcome to FanGraphs Baseball
      </h1>
      <p className="text-white text-sm font-normal leading-normal">
        The most sophisticated baseball simulator in the world.
      </p>
    </div>
  </section>
);