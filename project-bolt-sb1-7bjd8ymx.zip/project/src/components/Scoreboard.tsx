import React from 'react';
import { useGameStore } from '../store/gameStore';

export const Scoreboard = () => {
  const { gameState } = useGameStore();

  return (
    <div className="bg-gray-900 text-white p-4 rounded-lg shadow-lg">
      <div className="grid grid-cols-2 gap-4">
        <div className="text-center">
          <h3 className="text-xl font-bold">Away</h3>
          <p className="text-3xl">{gameState.awayScore}</p>
        </div>
        <div className="text-center">
          <h3 className="text-xl font-bold">Home</h3>
          <p className="text-3xl">{gameState.homeScore}</p>
        </div>
      </div>
      
      <div className="mt-4 grid grid-cols-3 gap-2 text-center">
        <div>
          <p className="text-sm">Inning</p>
          <p className="font-bold">{`${gameState.isTopInning ? '▲' : '▼'} ${gameState.inning}`}</p>
        </div>
        <div>
          <p className="text-sm">Outs</p>
          <p className="font-bold">{gameState.outs}</p>
        </div>
        <div>
          <p className="text-sm">Count</p>
          <p className="font-bold">{`${gameState.balls}-${gameState.strikes}`}</p>
        </div>
      </div>
    </div>
  );
};