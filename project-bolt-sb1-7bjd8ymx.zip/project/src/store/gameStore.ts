import { create } from 'zustand';
import type { GameState } from '../types/game';

interface GameStore {
  gameState: GameState;
  setGameState: (state: Partial<GameState>) => void;
  resetGame: () => void;
}

const initialState: GameState = {
  inning: 1,
  isTopInning: true,
  outs: 0,
  balls: 0,
  strikes: 0,
  baseRunners: [null, null, null],
  currentBatter: null,
  currentPitcher: null,
  homeScore: 0,
  awayScore: 0,
};

export const useGameStore = create<GameStore>((set) => ({
  gameState: initialState,
  setGameState: (newState) =>
    set((state) => ({
      gameState: { ...state.gameState, ...newState },
    })),
  resetGame: () => set({ gameState: initialState }),
}));