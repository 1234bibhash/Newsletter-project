import React from 'react';
import { createBrowserRouter } from 'react-router-dom';
import { Layout } from '../components/layout/Layout';
import { HomePage } from '../pages/HomePage';
import { GamePage } from '../pages/GamePage';
import { LiveGamePage } from '../pages/LiveGamePage';
import { ProfilePage } from '../pages/ProfilePage';
import { GameDetailsPage } from '../pages/GameDetailsPage';

export const router = createBrowserRouter([
  {
    path: '/',
    element: <Layout />,
    children: [
      { index: true, element: <HomePage /> },
      { path: 'games', element: <GamePage /> },
      { path: 'games/:id', element: <GameDetailsPage /> },
      { path: 'live', element: <LiveGamePage /> },
      { path: 'profile', element: <ProfilePage /> },
    ],
  },
]);