/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      // Enable container queries
      containerQueries: {
        '@sm': '480px',
        '@md': '768px',
        '@lg': '1024px',
        '@xl': '1280px',
      },
    },
  },
  plugins: [
    // Add container queries plugin
    require('@tailwindcss/container-queries'),
  ],
};